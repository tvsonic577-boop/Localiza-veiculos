import React from 'react';
import { Car, Bike, Trash2, Calendar, Tag, ChevronLeft, ChevronRight, Pencil } from 'lucide-react';
import { Vehicle } from '../types';
import { formatCurrency } from '../lib/utils';
import { motion } from 'motion/react';

interface Props {
  vehicle: Vehicle;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
  onEdit?: (vehicle: Vehicle) => void;
  onViewDetails?: (vehicle: Vehicle) => void;
  onViewImage?: (vehicle: Vehicle, index: number) => void;
}

export const VehicleCard = ({ vehicle, isAdmin, onDelete, onEdit, onViewDetails, onViewImage }: Props) => {
  const [currentImage, setCurrentImage] = React.useState(0);
  const images = vehicle.images || [];

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-zinc-950 rounded-2xl overflow-hidden shadow-2xl hover:shadow-blue-950/10 hover:border-zinc-800 transition-all border border-zinc-900 flex flex-col group"
    >
      <div 
        onClick={() => images.length > 0 && onViewImage?.(vehicle, currentImage)}
        className="relative aspect-video bg-zinc-900 overflow-hidden cursor-zoom-in"
      >
        {images.length > 0 ? (
          <>
            <img 
              src={images[currentImage]} 
              alt={`${vehicle.brand} ${vehicle.model}`}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            {images.length > 1 && (
              <div className="absolute inset-0 flex items-center justify-between px-2 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    setCurrentImage(prev => prev === 0 ? images.length - 1 : prev - 1);
                  }}
                  className="bg-black/70 text-white p-1.5 rounded-full backdrop-blur-sm hover:bg-black/95 transition-colors border border-zinc-850"
                >
                  <ChevronLeft size={18} />
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    setCurrentImage(prev => prev === images.length - 1 ? 0 : prev + 1);
                  }}
                  className="bg-black/70 text-white p-1.5 rounded-full backdrop-blur-sm hover:bg-black/95 transition-colors border border-zinc-850"
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            )}
            <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-sm text-zinc-350 px-2 py-1 rounded text-[10px] font-bold border border-zinc-850">
              {currentImage + 1} / {images.length}
            </div>
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-zinc-650 gap-2">
            {vehicle.type === 'car' ? <Car size={44} /> : <Bike size={44} />}
            <span className="text-xs font-semibold uppercase tracking-wider">Sem foto</span>
          </div>
        )}
        
        <div className="absolute top-3 left-3 bg-zinc-950/90 backdrop-blur shadow-sm px-3 py-1 rounded-full flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-wider border border-zinc-800 text-zinc-200">
          <Tag size={12} className="text-blue-500" />
          {vehicle.type === 'car' ? 'Carro' : 'Moto'}
        </div>

        {isAdmin && (
          <div className="absolute top-3 right-3 flex gap-2 opacity-100 md:opacity-0 md:group-hover:opacity-100 focus-within:opacity-100 transition-all duration-200">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                onEdit?.(vehicle);
              }}
              className="bg-blue-600 text-white p-2 rounded-full shadow-lg hover:bg-blue-700 hover:scale-105 transition-all text-sm font-semibold"
              title="Editar anúncio"
            >
              <Pencil size={15} />
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                onDelete?.(vehicle.id);
              }}
              className="bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-650 hover:scale-105 transition-all text-sm font-semibold"
              title="Excluir"
            >
              <Trash2 size={15} />
            </button>
          </div>
        )}
      </div>

      <div className="p-5 flex-1 flex flex-col bg-zinc-950">
        <div className="flex justify-between items-start mb-2 gap-2">
          <h3 className="font-extrabold text-white text-base leading-tight uppercase tracking-tight">
            {vehicle.brand} <span className="font-medium text-zinc-400 normal-case">{vehicle.model}</span>
          </h3>
          <span className="bg-zinc-900 border border-zinc-800 text-zinc-350 px-2 py-0.5 rounded-lg text-[10px] font-black flex items-center gap-1 shrink-0">
            <Calendar size={10} />
            {vehicle.year}
          </span>
        </div>

        <p className="text-zinc-400 text-sm mb-3 line-clamp-2 flex-1 leading-relaxed">
          {vehicle.description || 'Nenhuma descrição fornecida.'}
        </p>

        {/* Advertiser info & location */}
        <div className="flex flex-col gap-1 text-[11px] text-zinc-500 mb-4 font-bold tracking-wide uppercase">
          {vehicle.advertiserName && (
            <div className="flex items-center gap-1 text-zinc-400 truncate">
              <span className="text-blue-500 text-[9px] font-black tracking-widest bg-blue-500/10 px-1.5 py-0.5 rounded-md mr-1 uppercase">Anunciante</span> 
              <span className="truncate">{vehicle.advertiserName}</span>
            </div>
          )}
          {vehicle.city && (
            <div className="flex items-center gap-1 text-zinc-400 truncate">
              <span className="text-zinc-500 font-bold">Local:</span> 
              <span className="text-zinc-300 truncate">{vehicle.city}</span>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-zinc-900 flex items-center justify-between">
          <div className="text-xl font-black text-blue-500">
            {formatCurrency(vehicle.price)}
          </div>
          <button 
            onClick={() => onViewDetails?.(vehicle)}
            className="bg-zinc-900 border border-zinc-800 hover:border-zinc-750 text-white px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider hover:bg-zinc-850 transition-all"
          >
            Detalhes
          </button>
        </div>
      </div>
    </motion.div>
  );
};
