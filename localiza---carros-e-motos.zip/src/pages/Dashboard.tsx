import React, { useState, useEffect } from 'react';
import { collection, addDoc, onSnapshot, deleteDoc, doc, query, orderBy, serverTimestamp, Timestamp, updateDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Vehicle, Client, VehicleType } from '../types';
import { VehicleCard } from '../components/VehicleCard';
import { Plus, UserPlus, Users, Package, LogOut, X, Camera, Car, Bike, Mail, Phone, Upload, MapPin, User, Shield, Trash2, ShieldAlert } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { formatCurrency } from '../lib/utils';

export const Dashboard = () => {
  const { user, userProfile, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [allRegisteredUsers, setAllRegisteredUsers] = useState<any[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [showVehicleModal, setShowVehicleModal] = useState(false);
  const [showClientModal, setShowClientModal] = useState(false);
  
  // Tabs: 'vehicles', 'clients' (admin only), 'users' (admin only)
  const [activeTab, setActiveTab] = useState<'vehicles' | 'clients' | 'users'>('vehicles');
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);

  const handleEditVehicle = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setShowVehicleModal(true);
  };

  const formatDate = (date: any) => {
    if (!date) return '-';
    if (date instanceof Timestamp) {
      return date.toDate().toLocaleDateString('pt-BR');
    }
    if (typeof date === 'number') {
      return new Date(date).toLocaleDateString('pt-BR');
    }
    if (date.seconds) { // Firestore custom JSON format
      return new Date(date.seconds * 1000).toLocaleDateString('pt-BR');
    }
    return new Date(date).toLocaleDateString('pt-BR');
  };

  // Redirect to login if user is not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  // Hook subscriptions
  useEffect(() => {
    if (!user) return;

    // Load Vehicles
    const vUnsub = onSnapshot(query(collection(db, 'vehicles'), orderBy('createdAt', 'desc')), (s) => {
      const allv = s.docs.map(d => ({ id: d.id, ...d.data() } as Vehicle));
      if (isAdmin) {
        setVehicles(allv);
      } else {
        // Regular user only sees their own classifieds
        setVehicles(allv.filter(v => v.ownerId === user.uid));
      }
    }, (error) => {
      console.error("Error fetching vehicles:", error);
    });

    // Load Clients (Admin only)
    let cUnsub = () => {};
    if (isAdmin) {
      cUnsub = onSnapshot(query(collection(db, 'clients'), orderBy('createdAt', 'desc')), (s) => {
        setClients(s.docs.map(d => ({ id: d.id, ...d.data() } as Client)));
      }, (error) => {
        console.error("Error fetching clients:", error);
      });
    }

    // Load Registered Users (Admin only)
    let uUnsub = () => {};
    if (isAdmin) {
      uUnsub = onSnapshot(query(collection(db, 'users'), orderBy('createdAt', 'desc')), (s) => {
        setAllRegisteredUsers(s.docs.map(d => ({ id: d.id, ...d.data() })));
      }, (error) => {
        console.error("Error fetching registered users:", error);
      });
    }

    return () => {
      vUnsub();
      cUnsub();
      uUnsub();
    };
  }, [user, isAdmin]);

  const handleDeleteVehicle = async (id: string) => {
    if (window.confirm('Deseja realmente excluir este anúncio?')) {
      try {
        await deleteDoc(doc(db, 'vehicles', id));
        alert('Anúncio excluído com sucesso!');
      } catch (err) {
        console.error("Error deleting vehicle:", err);
        alert('Erro ao excluir anúncio.');
      }
    }
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    if (window.confirm(`Tem certeza de que deseja excluir a conta de "${userName}"? Todos os anúncios associados a este usuário também serão excluídos permanentemente.`)) {
      try {
        // Delete users document from DB
        await deleteDoc(doc(db, 'users', userId));

        // Delete all vehicles belonging to this user
        const associatedVehicles = vehicles.filter(v => v.ownerId === userId);
        let deletedCount = 0;
        for (const item of associatedVehicles) {
          await deleteDoc(doc(db, 'vehicles', item.id));
          deletedCount++;
        }

        alert(`Conta de ${userName} excluída! ${deletedCount} anúncios dele foram removidos.`);
      } catch (err) {
        console.error("Error deleting user:", err);
        alert('Erro ao excluir permissões de usuário.');
      }
    }
  };

  const handleLogout = () => {
    auth.signOut();
    navigate('/');
  };

  if (authLoading) return <div className="p-20 text-center text-zinc-500">Carregando painel...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between sticky top-0 z-40 shadow-sm">
        <div className="flex flex-col">
          <span className="text-lg font-black tracking-tighter uppercase text-gray-900">
            <span className="text-xl">L</span>ocaliza <span className="text-blue-600"><span className="text-xl">V</span>eículos</span>
          </span>
          <span className="text-[9px] text-gray-500 uppercase tracking-widest font-bold">
            {isAdmin ? 'Painel ADM' : 'Meu Painel'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <select
              value={activeTab}
              onChange={(e) => setActiveTab(e.target.value as any)}
              className="bg-blue-50 border-none text-blue-700 px-3 py-1.5 rounded-xl text-xs font-bold focus:ring-1 focus:ring-blue-300"
            >
              <option value="vehicles">Estoque</option>
              <option value="clients">Clientes</option>
              <option value="users">Usuários</option>
            </select>
          )}
          <button 
            onClick={handleLogout}
            className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
            title="Sair"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>

      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 hidden md:flex flex-col">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-xl font-black text-gray-900 uppercase">
            <span className="text-2xl">L</span>ocaliza <span className="text-blue-600"><span className="text-2xl">V</span></span>
          </h2>
          <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider mt-1">
            {isAdmin ? 'Administração Global' : 'Painel do Anunciante'}
          </p>
          <div className="mt-3 p-2.5 bg-zinc-50 rounded-xl flex items-center gap-2 border border-zinc-100">
            <div className="bg-blue-600/10 p-1.5 rounded-lg text-blue-600">
              <User size={14} />
            </div>
            <div className="truncate">
              <p className="text-xs font-bold text-zinc-800 leading-tight truncate">{userProfile?.name || user?.displayName || 'Usuário'}</p>
              <p className="text-[9px] text-zinc-400 font-medium truncate">{user?.email}</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          <button 
            onClick={() => setActiveTab('vehicles')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-colors ${activeTab === 'vehicles' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'}`}
          >
            <Package size={20} />
            {isAdmin ? 'Estoque Geral' : 'Meus Anúncios'}
          </button>

          {isAdmin && (
            <>
              <button 
                onClick={() => setActiveTab('clients')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-colors ${activeTab === 'clients' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                <Users size={20} />
                Clientes
              </button>

              <button 
                onClick={() => setActiveTab('users')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-colors ${activeTab === 'users' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'}`}
              >
                <Shield size={20} />
                Usuários
              </button>
            </>
          )}
        </nav>

        <div className="p-4 border-t border-gray-100">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold text-red-600 hover:bg-red-50 transition-colors"
          >
            <LogOut size={20} />
            Sair da Conta
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-6 md:p-10 overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 sm:mb-10">
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-gray-900 uppercase tracking-tight">
              {activeTab === 'vehicles' 
                ? (isAdmin ? 'Gestão de Estoque Geral' : 'Meus Classificados') 
                : activeTab === 'clients' ? 'Gestão de Clientes' : 'Usuários Cadastrados'}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 mt-1">
              Olá, <strong className="text-zinc-800">{userProfile?.name || user?.displayName || 'Membro'}</strong>. {isAdmin ? 'Gerencie o portal geral.' : 'Anuncie e modifique as fotos de seus veículos.'}
            </p>
          </div>
          
          {activeTab === 'vehicles' && (
            <button 
              onClick={() => {
                setEditingVehicle(null);
                setShowVehicleModal(true);
              }}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white px-5 sm:px-6 py-3.5 rounded-xl sm:rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all hover:-translate-y-1 w-full sm:w-auto uppercase tracking-wide text-xs sm:text-sm"
            >
              <Plus size={18} />
              Criar Novo Anúncio
            </button>
          )}

          {activeTab === 'clients' && isAdmin && (
            <button 
              onClick={() => setShowClientModal(true)}
              className="flex items-center justify-center gap-2 bg-blue-600 text-white px-5 sm:px-6 py-3.5 rounded-xl sm:rounded-2xl font-bold shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all hover:-translate-y-1 w-full sm:w-auto uppercase tracking-wide text-xs sm:text-sm"
            >
              <UserPlus size={18} />
              Cadastrar Cliente
            </button>
          )}
        </header>

        {activeTab === 'vehicles' ? (
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              <AnimatePresence>
                {vehicles.map(v => (
                  <VehicleCard 
                    key={v.id} 
                    vehicle={v} 
                    isAdmin={true} // Users can edit their own shown list, backend handles auth
                    onDelete={handleDeleteVehicle} 
                    onEdit={handleEditVehicle} 
                  />
                ))}
              </AnimatePresence>
            </div>
            {vehicles.length === 0 && (
              <div className="bg-white border border-gray-150 rounded-3xl p-12 text-center max-w-xl mx-auto mt-6 shadow-sm">
                <Car className="mx-auto text-zinc-300 mb-4" size={54} />
                <h3 className="font-bold text-gray-800 text-lg">Nenhum anúncio publicado</h3>
                <p className="text-zinc-500 text-sm mt-1 mb-6">Você ainda não possui anúncios. Comece agora mesmo clicando no botão acima!</p>
                <button 
                  onClick={() => setShowVehicleModal(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold text-sm transition-all"
                >
                  Anunciar Meu Carro ou Moto
                </button>
              </div>
            )}
          </div>
        ) : activeTab === 'clients' ? (
          <>
            <div className="mb-6 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-3xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl shadow-blue-100">
              <div>
                <h3 className="text-lg font-bold">Gerencie Leads e Propostas</h3>
                <p className="text-blue-100 text-sm">Controle todos os e-mails e celulares capturados pelo sistema a partir dos anúncios.</p>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-6 py-4 font-bold text-gray-700">Nome</th>
                      <th className="px-6 py-4 font-bold text-gray-700">Contato</th>
                      <th className="px-6 py-4 font-bold text-gray-700">Cadastrado em</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {clients.map(c => (
                      <tr key={c.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4 font-semibold text-gray-900">{c.name}</td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col text-sm">
                            {c.email && <span className="flex items-center gap-1.5 text-gray-650"><Mail size={14} /> {c.email}</span>}
                            <span className="flex items-center gap-1.5 text-blue-600 font-medium"><Phone size={14} /> {c.phone}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-500 text-sm">
                          {formatDate(c.createdAt)}
                        </td>
                      </tr>
                    ))}
                    {clients.length === 0 && (
                      <tr>
                        <td colSpan={3} className="px-6 py-12 text-center text-gray-400">Nenhum cliente cadastrado.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          /* Users tab (Admin only) */
          <>
            <div className="mb-6 bg-gradient-to-r from-red-500/10 to-transparent rounded-2xl p-5 border border-red-500/15 flex items-center gap-4 text-red-700">
              <ShieldAlert size={28} className="flex-shrink-0" />
              <div>
                <h3 className="font-bold text-sm sm:text-base">Controle de Segurança do Administrador</h3>
                <p className="text-xs text-red-600/80">Como administrador, você pode suspender ou remover permanentemente qualquer conta de anunciante. Isso limpará suas postagens automaticamente.</p>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-100">
                    <tr>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider">Nome Completo</th>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider">E-mail</th>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider">WhatsApp</th>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider">Cidade / Estado</th>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider">Data do Cadastro</th>
                      <th className="px-6 py-4 font-bold text-gray-700 text-xs uppercase tracking-wider text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-sm">
                    {allRegisteredUsers.map(u => (
                      <tr key={u.id || u.uid} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4 font-bold text-gray-900">{u.name || 'Sem nome'}</td>
                        <td className="px-6 py-4 text-gray-600">{u.email || '-'}</td>
                        <td className="px-6 py-4 text-blue-600 font-semibold">{u.phone || '-'}</td>
                        <td className="px-6 py-4 text-gray-500">{u.city || '-'}</td>
                        <td className="px-6 py-4 text-gray-400">{formatDate(u.createdAt)}</td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => handleDeleteUser(u.uid || u.id, u.name || u.email)}
                            className="bg-red-50 hover:bg-red-100 text-red-600 px-3.5 py-1.5 rounded-xl font-bold text-xs inline-flex items-center gap-1.5 transition-all text-center"
                            title="Remover usuário"
                          >
                            <Trash2 size={13} />
                            Excluir Usuário
                          </button>
                        </td>
                      </tr>
                    ))}
                    {allRegisteredUsers.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-12 text-center text-gray-400">Nenhum anunciante cadastrado no banco.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>

      {/* Modals */}
      <AnimatePresence>
        {showVehicleModal && (
          <VehicleFormModal 
            vehicle={editingVehicle} 
            onClose={() => {
              setShowVehicleModal(false);
              setEditingVehicle(null);
            }} 
          />
        )}
        {showClientModal && <ClientFormModal onClose={() => setShowClientModal(false)} />}
      </AnimatePresence>
    </div>
  );
};

// Helper function to compress and convert file to Base64
const compressFileToBase64 = (file: File, onProgress?: (progress: number) => void): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onprogress = (event) => {
      if (event.lengthComputable && onProgress) {
        const percent = Math.round((event.loaded / event.total) * 40); // Reading file takes 40%
        onProgress(percent);
      }
    };
    
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      if (onProgress) onProgress(40);
      
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const maxDimension = 720; // Excellent mobile/desktop width, lightweight size

        if (width > height) {
          if (width > maxDimension) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          }
        } else {
          if (height > maxDimension) {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.65); // Balance between quality and file size (under 80KB)
          if (onProgress) onProgress(100);
          resolve(compressedBase64);
        } else {
          if (onProgress) onProgress(100);
          resolve(event.target?.result as string);
        }
      };
      img.onerror = (err) => {
        console.error("Canvas image loading failed", err);
        if (onProgress) onProgress(100);
        resolve(event.target?.result as string); // Fallback to raw base64
      };
    };
    reader.onerror = (err) => {
      console.error("File reader failed", err);
      reject(err);
    };
  });
};

const formatBRLInput = (val: string | number) => {
  if (val === undefined || val === null || val === '') return '';
  const clean = String(val).replace(/\D/g, '');
  if (!clean) return '';
  const num = parseInt(clean, 10);
  return 'R$ ' + new Intl.NumberFormat('pt-BR', {
    maximumFractionDigits: 0
  }).format(num);
};

const VehicleFormModal = ({ vehicle, onClose }: { vehicle?: Vehicle | null, onClose: () => void }) => {
  const { userProfile, isAdmin } = useAuth();
  
  const [formData, setFormData] = useState({
    brand: vehicle?.brand || '',
    model: vehicle?.model || '',
    year: vehicle?.year || new Date().getFullYear(),
    price: vehicle?.price ? formatBRLInput(vehicle.price) : '' as string | number,
    description: vehicle?.description || '',
    type: (vehicle?.type || 'car') as VehicleType,
    imageUrl: '',
    city: vehicle?.city || userProfile?.city || '',
    phone: vehicle?.phone || userProfile?.phone || '',
    advertiserName: vehicle?.advertiserName || userProfile?.name || ''
  });
  const [existingImages, setExistingImages] = useState<string[]>(vehicle?.images || []);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [clients, setClients] = useState<Client[]>([]);

  useEffect(() => {
    // Only subscribe for clients drop down if user is admin
    if (!isAdmin) return;
    const unsub = onSnapshot(query(collection(db, 'clients'), orderBy('name', 'asc')), (s) => {
      setClients(s.docs.map(d => ({ id: d.id, ...d.data() } as Client)));
    });
    return unsub;
  }, [isAdmin]);

  useEffect(() => {
    if (!vehicle && userProfile) {
      setFormData(prev => ({
        ...prev,
        city: prev.city || userProfile.city || '',
        phone: prev.phone || userProfile.phone || '',
        advertiserName: prev.advertiserName || userProfile.name || ''
      }));
    }
  }, [userProfile, vehicle]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      const totalCount = existingImages.length + selectedFiles.length;
      if (totalCount >= 7) {
        alert('Você já atingiu o limite de 7 fotos.');
        return;
      }
      const newFiles = [...selectedFiles, ...files].slice(0, 7 - existingImages.length);
      setSelectedFiles(newFiles);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const removeExistingImage = (index: number) => {
    setExistingImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;
    
    setSaving(true);
    setUploadProgress({});
    
    try {
      const uploadedUrls: string[] = [...existingImages];

      // 1. Convert and compress multiple files to Base64
      if (selectedFiles.length > 0) {
        const uploadPromises = selectedFiles.map((file, index) => {
          return compressFileToBase64(file, (progress) => {
            setUploadProgress(prev => ({ ...prev, [index]: progress }));
          });
        });

        const urls = await Promise.all(uploadPromises);
        uploadedUrls.push(...urls);
      }

      // 2. Handle URL input (if provided)
      if (formData.imageUrl && !uploadedUrls.includes(formData.imageUrl)) {
        uploadedUrls.push(formData.imageUrl);
      }

      if (uploadedUrls.length === 0) {
        throw new Error('Adicione pelo menos uma foto do veículo.');
      }

      // 3. Auto-save client info to DB if Admin is creating/linking
      if (isAdmin && formData.advertiserName && formData.phone) {
        const phoneClean = formData.phone.trim();
        const nameClean = formData.advertiserName.trim();
        const exists = clients.some(c => 
          c.phone?.trim() === phoneClean || 
          c.name?.trim().toLowerCase() === nameClean.toLowerCase()
        );
        if (!exists) {
          await addDoc(collection(db, 'clients'), {
            name: nameClean,
            phone: phoneClean,
            email: '',
            createdAt: serverTimestamp()
          });
        }
      }

      const rawPrice = Number(String(formData.price).replace(/\D/g, ''));

      const vehicleData = {
        brand: formData.brand,
        model: formData.model,
        year: Number(formData.year),
        price: rawPrice,
        description: formData.description,
        type: formData.type,
        images: uploadedUrls,
        ownerId: vehicle ? (vehicle.ownerId || auth.currentUser?.uid) : auth.currentUser?.uid,
        updatedAt: serverTimestamp(),
        city: formData.city,
        phone: formData.phone,
        advertiserName: formData.advertiserName
      };

      if (vehicle) {
        await updateDoc(doc(db, 'vehicles', vehicle.id), vehicleData);
        alert('Veículo atualizado com sucesso!');
      } else {
        await addDoc(collection(db, 'vehicles'), {
          ...vehicleData,
          createdAt: serverTimestamp()
        });
        alert('Veículo publicado com sucesso!');
      }

      setFormData({ 
        brand: '', 
        model: '', 
        year: new Date().getFullYear(), 
        price: '', 
        description: '', 
        type: 'car', 
        imageUrl: '',
        city: '',
        phone: '',
        advertiserName: ''
      });
      setSelectedFiles([]);
      setExistingImages([]);
      setUploadProgress({});
      onClose();
    } catch (err: any) {
      console.error("Save Error:", err);
      let message = 'Erro ao salvar veículo: ' + (err.message || 'Erro desconhecido');
      
      if (err.code === 'storage/retry-limit-exceeded') {
        message = 'Ocorreu um erro de conexão ao enviar as fotos. Verifique sua internet ou tente novamente com fotos menores.';
      } else if (err.code === 'storage/unauthorized') {
        message = 'Você não tem permissão para carregar fotos.';
      } else if (err.message?.includes('permission-denied')) {
        message = 'Permissão negada no banco de dados.';
      }
      
      alert(message);
    } finally {
      setSaving(false);
    }
  };

  const totalPhotosCount = existingImages.length + selectedFiles.length;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-2 sm:p-4">
      <motion.div 
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative bg-white w-full max-w-lg rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        <div className="p-5 sm:p-6 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 shrink-0">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">{vehicle ? 'Editar Veículo' : 'Novo Veículo'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><X size={20}/></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-8 space-y-4 sm:space-y-5 overflow-y-auto flex-1">
          <div className="flex gap-4">
            <button 
              type="button" 
              onClick={() => setFormData(prev => ({...prev, type: 'car'}))}
              className={`flex-1 flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${formData.type === 'car' ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-gray-100 hover:border-gray-200 text-gray-500'}`}
            >
              <Car size={32} />
              <span className="font-bold">Carro</span>
            </button>
            <button 
              type="button" 
              onClick={() => setFormData(prev => ({...prev, type: 'motorcycle'}))}
              className={`flex-1 flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${formData.type === 'motorcycle' ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-gray-100 hover:border-gray-200 text-gray-500'}`}
            >
              <Bike size={32} />
              <span className="font-bold">Moto</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Marca</label>
              <input required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-900" placeholder="Ex: Toyota" value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})} />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Modelo</label>
              <input required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-900" placeholder="Ex: Corolla" value={formData.model} onChange={e => setFormData({...formData, model: e.target.value})} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Ano</label>
              <input type="number" required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-900" value={formData.year} onChange={e => setFormData({...formData, year: Number(e.target.value)})} />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Preço</label>
              <input 
                type="text" 
                required 
                className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none font-semibold text-gray-950" 
                placeholder="R$ 0" 
                value={formData.price} 
                onChange={e => setFormData({...formData, price: formatBRLInput(e.target.value)})} 
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Fotos do Veículo (Máx. 7)</label>
            
            {/* Multi-File Upload Area */}
            <div className="grid grid-cols-1 gap-4">
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                <AnimatePresence>
                  {/* Render existing images */}
                  {existingImages.map((imgUrl, index) => (
                    <motion.div 
                       key={`existing-${index}`}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="relative aspect-square rounded-xl overflow-hidden bg-gray-100 group"
                    >
                      <img 
                        src={imgUrl} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                      />
                      <button 
                        type="button"
                        onClick={() => removeExistingImage(index)}
                        className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-lg opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity"
                        title="Remover foto"
                      >
                        <X size={12} />
                      </button>
                    </motion.div>
                  ))}

                  {/* Render newly selected files */}
                  {selectedFiles.map((file, index) => (
                    <motion.div 
                       key={`new-${file.name}-${index}`}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="relative aspect-square rounded-xl overflow-hidden bg-gray-100 group"
                    >
                      <img 
                        src={URL.createObjectURL(file)} 
                        alt="Preview" 
                        className="w-full h-full object-cover"
                      />
                      {uploadProgress[index] !== undefined && uploadProgress[index] < 100 && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        </div>
                      )}
                      <button 
                        type="button"
                        onClick={() => removeFile(index)}
                        className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full shadow-lg opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity"
                        title="Remover foto"
                      >
                        <X size={12} />
                      </button>
                    </motion.div>
                  ))}
                  
                  {totalPhotosCount < 7 && (
                    <label 
                      htmlFor="file-upload"
                      className="aspect-square flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-gray-200 hover:border-blue-400 hover:bg-blue-50/30 cursor-pointer transition-all"
                    >
                      <Plus className="text-gray-400" size={20} />
                    </label>
                  )}
                </AnimatePresence>
              </div>

              <div className="relative">
                <input 
                  type="file" 
                  multiple
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden" 
                  id="file-upload"
                />
                {totalPhotosCount === 0 && (
                  <label 
                    htmlFor="file-upload"
                    className="flex flex-col items-center justify-center gap-3 p-8 rounded-2xl border-2 border-dashed cursor-pointer transition-all border-gray-200 hover:border-blue-400 hover:bg-blue-50/30"
                  >
                    <Upload className="text-gray-400" size={32} />
                    <div className="text-center">
                      <span className="block text-sm font-bold text-gray-700">Carregar da Galeria</span>
                      <span className="block text-xs text-gray-400 mt-1">Selecione até 7 fotos (PNG, JPG)</span>
                    </div>
                  </label>
                )}
              </div>

              <div className="relative">
                <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-gray-400">
                  <Camera size={18} />
                </div>
                <input 
                  className="w-full bg-gray-50 border-none rounded-xl py-3 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-950" 
                  placeholder="Ou cole a URL de uma imagem..." 
                  value={formData.imageUrl} 
                  onChange={e => setFormData({...formData, imageUrl: e.target.value})} 
                />
              </div>
            </div>
          </div>

          {/* Advertiser Connection and Info */}
          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-150 space-y-4">
            <span className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Informações do Anunciante</span>
            
            {isAdmin && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Vincular Cliente Salvo</label>
                <select 
                  className="w-full bg-white border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-750 text-sm font-semibold text-gray-900"
                  onChange={(e) => {
                    if (e.target.value === 'novo') {
                      setFormData(prev => ({ ...prev, advertiserName: '', phone: '' }));
                    } else {
                      const selected = clients.find(c => c.id === e.target.value);
                      if (selected) {
                        setFormData(prev => ({ ...prev, advertiserName: selected.name, phone: selected.phone }));
                      }
                    }
                  }}
                >
                  <option value="novo">-- Novo Cliente / Digitar Manualmente --</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.phone})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Nome do Anunciante *</label>
                <input 
                  required 
                  className="w-full bg-white border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-sm text-gray-900" 
                  placeholder="Ex: João da Silva" 
                  value={formData.advertiserName} 
                  onChange={e => setFormData({...formData, advertiserName: e.target.value})} 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Telefone / WhatsApp *</label>
                <input 
                  required 
                  className="w-full bg-white border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-sm text-gray-900" 
                  placeholder="Ex: (11) 99999-9999" 
                  value={formData.phone} 
                  onChange={e => setFormData({...formData, phone: e.target.value})} 
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Cidade / Estado do Veículo *</label>
              <input 
                required 
                className="w-full bg-white border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-blue-100 transition-all outline-none text-sm text-gray-900" 
                placeholder="Ex: São Paulo - SP" 
                value={formData.city} 
                onChange={e => setFormData({...formData, city: e.target.value})} 
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Descrição</label>
            <textarea className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 h-24 resize-none focus:ring-2 focus:ring-blue-100 transition-all outline-none text-gray-900" placeholder="Detalhes do estado do veículo..." value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
          </div>

          <button disabled={saving} className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-blue-200 hover:bg-blue-700 hover:-translate-y-1 transition-all disabled:opacity-50 disabled:translate-y-0 disabled:shadow-none flex items-center justify-center gap-2">
            {saving ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Salvando Dados...
              </>
            ) : vehicle ? 'Salvar Alterações' : 'Publicar Anúncio'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const ClientFormModal = ({ onClose }: { onClose: () => void }) => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '' });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await addDoc(collection(db, 'clients'), { ...formData, createdAt: serverTimestamp() });
      onClose();
    } catch (err) { alert('Erro ao salvar cliente'); } finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-2 sm:p-4">
      <motion.div 
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative bg-white w-full max-w-md rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        <div className="p-5 sm:p-6 border-b border-gray-100 flex items-center justify-between shrink-0">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">Novo Cliente</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><X size={20}/></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 sm:p-8 space-y-4 sm:space-y-5 overflow-y-auto flex-1">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase">Nome Completo</label>
            <input required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 text-gray-900" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase">Email</label>
            <input type="email" required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 text-gray-900" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase">Telefone / WhatsApp</label>
            <input required className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 text-gray-900" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
          </div>
          <button disabled={saving} className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all disabled:opacity-50">
            {saving ? 'Cadastrando...' : 'Salvar Cliente'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};
