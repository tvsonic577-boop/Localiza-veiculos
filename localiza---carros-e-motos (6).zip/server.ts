import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const currentFilename = typeof __filename !== "undefined" 
  ? __filename 
  : (typeof import.meta !== "undefined" && import.meta.url ? fileURLToPath(import.meta.url) : "");

const currentDirname = typeof __dirname !== "undefined" 
  ? __dirname 
  : path.dirname(currentFilename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middlewares
  app.use(express.json());

  // Log requests for diagnostics
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });

  // API Route: Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", uptime: process.uptime() });
  });

  // API Route: Create Pix Payment via Mercado Pago
  app.post("/api/payments/create", async (req, res) => {
    try {
      const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;
      if (!accessToken) {
        return res.status(400).json({
          error: "O Token de Acesso do Mercado Pago não está configurado. Adicione MERCADO_PAGO_ACCESS_TOKEN nas Configurações (Settings) do AI Studio."
        });
      }

      const { userId, email, name, cpf } = req.body;
      if (!userId || !email) {
        return res.status(400).json({ error: "Parâmetros userId e email são obrigatórios." });
      }

      // Format CPF
      const cleanCpf = cpf ? cpf.replace(/\D/g, "") : "19100000000";

      // Split name safely
      const nameParts = (name || "Anunciante Localiza").trim().split(" ");
      const firstName = nameParts[0] || "Anunciante";
      const lastName = nameParts.slice(1).join(" ") || "Localiza";

      const idempotencyKey = `lv-${userId}-${Date.now()}`;
      const payload = {
        transaction_amount: 9.99,
        description: "Recarga de 10 créditos - Localiza Veículos",
        payment_method_id: "pix",
        payer: {
          email: email,
          first_name: firstName,
          last_name: lastName,
          identification: {
            type: "CPF",
            number: cleanCpf
          }
        },
        metadata: {
          user_id: userId
        },
        notification_url: process.env.APP_URL ? `${process.env.APP_URL}/api/webhook/mercadopago` : undefined
      };

      console.log(`Creating Pix payment on Mercado Pago for user ${userId} (CPF: ${cleanCpf})...`);

      const response = await fetch("https://api.mercadopago.com/v1/payments", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          "X-Idempotency-Key": idempotencyKey
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("Mercado Pago API error:", data);
        const detailMsg = data.message || (data.cause && data.cause[0] && data.cause[0].description) || "Erro desconhecido";
        return res.status(400).json({
          error: `Erro ao gerar Pix no Mercado Pago: ${detailMsg}`
        });
      }

      // Extract transaction data
      const qrCode = data.point_of_interaction?.transaction_data?.qr_code;
      const qrCodeBase64 = data.point_of_interaction?.transaction_data?.qr_code_base64;
      const ticketUrl = data.point_of_interaction?.transaction_data?.ticket_url;

      res.json({
        paymentId: data.id,
        status: data.status,
        qrCode: qrCode,
        qrCodeBase64: qrCodeBase64,
        ticketUrl: ticketUrl
      });
    } catch (err: any) {
      console.error("Error creating payment:", err);
      res.status(500).json({ error: err.message || "Erro interno do servidor ao criar pagamento." });
    }
  });

  // API Route: Query Payment Status from Mercado Pago
  app.get("/api/payments/status/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const accessToken = process.env.MERCADO_PAGO_ACCESS_TOKEN;
      if (!accessToken) {
        return res.status(400).json({ error: "Token do Mercado Pago não configurado." });
      }

      const response = await fetch(`https://api.mercadopago.com/v1/payments/${id}`, {
        headers: {
          "Authorization": `Bearer ${accessToken}`
        }
      });

      if (!response.ok) {
        return res.status(400).json({ error: "Não foi possível obter o status do pagamento." });
      }

      const data = await response.json();
      res.json({
        paymentId: data.id,
        status: data.status,
        statusDetail: data.status_detail
      });
    } catch (err: any) {
      console.error("Error getting payment status:", err);
      res.status(500).json({ error: err.message });
    }
  });

  // API Route: Webhook receiver for instant notification
  app.post("/api/webhook/mercadopago", async (req, res) => {
    try {
      console.log("Received webhook from Mercado Pago:", JSON.stringify(req.body));
      const paymentId = req.body?.data?.id || req.body?.id || req.query?.id;
      
      if (!paymentId) {
        return res.status(200).json({ message: "No payment ID found in webhook payload." });
      }

      const accessToken = process.env.MERCAGO_PAGO_ACCESS_TOKEN || process.env.MERCADO_PAGO_ACCESS_TOKEN;
      if (!accessToken) {
        console.error("MERCADO_PAGO_ACCESS_TOKEN missing, cannot process webhook.");
        return res.status(200).json({ message: "Access token missing, webhook logged but skipped" });
      }

      // Fetch payment detail directly from Mercado Pago
      console.log(`Verifying payment details for payment ID: ${paymentId}`);
      const mpRes = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: {
          "Authorization": `Bearer ${accessToken}`
        }
      });

      if (!mpRes.ok) {
        console.error(`Failed to fetch payment details from MP for payment ID ${paymentId}`);
        return res.status(200).json({ message: "Payment not found on MP, logged but skipped" });
      }

      const paymentData = await mpRes.json();
      const status = paymentData.status;
      const userId = paymentData.metadata?.user_id;

      console.log(`Payment details fetched: status=${status}, userId=${userId}`);

      if (status === "approved" && userId) {
        console.log(`Payment approved for user ${userId}. Balance will be synchronized via client-side polling.`);
        return res.status(200).json({ message: "Success. Payment approved, client will update database." });
      }

      return res.status(200).json({ message: `Received. Status: ${status}` });
    } catch (err: any) {
      console.error("Webhook processing error:", err);
      res.status(200).json({ error: err.message });
    }
  });

  // Vite development integration or production static server
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
