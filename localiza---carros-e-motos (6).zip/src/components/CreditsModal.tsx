import React, { useState, useEffect, useRef } from 'react';
import { X, Coins, Copy, Check, ExternalLink, QrCode, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface CreditsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  userProfile: any;
  refreshProfile: () => Promise<void>;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({
  isOpen,
  onClose,
  user,
  userProfile,
  refreshProfile,
}) => {
  const [cpf, setCpf] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Real payment state returned from Mercado Pago
  const [paymentData, setPaymentData] = useState<{
    paymentId: number;
    qrCode: string;
    qrCodeBase64: string;
    ticketUrl?: string;
  } | null>(null);
  
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // Interval ref for clean polling
  const pollingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Clean polling interval when modal closes or payment is approved
  useEffect(() => {
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, []);

  if (!isOpen) return null;

  // Real-time CPF formatting
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, "");
    let formatted = raw;
    if (raw.length > 3 && raw.length <= 6) {
      formatted = `${raw.substring(0, 3)}.${raw.substring(3)}`;
    } else if (raw.length > 6 && raw.length <= 9) {
      formatted = `${raw.substring(0, 3)}.${raw.substring(3, 6)}.${raw.substring(6)}`;
    } else if (raw.length > 9) {
      formatted = `${raw.substring(0, 3)}.${raw.substring(3, 6)}.${raw.substring(6, 9)}-${raw.substring(9, 11)}`;
    }
    setCpf(formatted.substring(0, 14));
  };

  const handleGeneratePix = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const cleanCpf = cpf.replace(/\D/g, "");
    if (cleanCpf.length !== 11) {
      setError("Por favor, informe um CPF válido com 11 dígitos.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/payments/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.uid,
          email: user.email,
          name: userProfile?.name || user.displayName || "Anunciante",
          cpf: cleanCpf,
        }),
      });

      const resData = await response.json();

      if (!response.ok) {
        throw new Error(resData.error || "Erro ao gerar chave Pix de pagamento.");
      }

      setPaymentData({
        paymentId: resData.paymentId,
        qrCode: resData.qrCode,
        qrCodeBase64: resData.qrCodeBase64,
        ticketUrl: resData.ticketUrl,
      });
      setPaymentStatus(resData.status || "pending");

      // Start Real-Time Polling for payment approval
      startPaymentPolling(resData.paymentId);
    } catch (err: any) {
      console.error("Error creating payment:", err);
      setError(err.message || "Não foi possível gerar o Pix. Verifique os dados ou tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const startPaymentPolling = (paymentId: number) => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }

    pollingIntervalRef.current = setInterval(async () => {
      try {
        const response = await fetch(`/api/payments/status/${paymentId}`);
        if (!response.ok) return;

        const data = await response.json();
        if (data.status === "approved") {
          // Clear polling immediately to avoid multiple triggers
          if (pollingIntervalRef.current) {
            clearInterval(pollingIntervalRef.current);
          }

          // Add +10 credits directly to user's profile in Firestore
          try {
            const userRef = doc(db, 'users', user.uid);
            const currentCredits = userProfile?.credits ?? 0;
            const newCredits = currentCredits + 10;
            await setDoc(userRef, { credits: newCredits }, { merge: true });
            console.log(`Successfully credited +10 credits. New balance: ${newCredits}`);
          } catch (dbErr) {
            console.error("Error updating credits in Firestore:", dbErr);
          }

          setPaymentStatus("approved");
          setSuccess(true);
          await refreshProfile();
        }
      } catch (err) {
        console.error("Error polling payment status:", err);
      }
    }, 3000);
  };

  const handleCopyPixCode = () => {
    if (!paymentData?.qrCode) return;
    navigator.clipboard.writeText(paymentData.qrCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClose = () => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
    }
    setError(null);
    setPaymentData(null);
    setPaymentStatus(null);
    setSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[999999] w-screen h-screen flex items-center justify-center p-4 bg-black/90 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden my-auto mx-auto">
        
        {/* Decorative ambient background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button 
          onClick={handleClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1.5 rounded-full hover:bg-zinc-900 transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        {success ? (
          <div className="flex flex-col items-center justify-center py-8 text-center animate-scale-up">
            <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 text-green-500 rounded-full flex items-center justify-center mb-6">
              <CheckCircle2 size={36} className="animate-pulse" />
            </div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tight">Pagamento Aprovado!</h3>
            <p className="text-zinc-400 text-sm mt-3 max-w-xs mx-auto leading-relaxed">
              Recebemos sua transferência Pix com sucesso. <br />
              <strong className="text-green-400 font-extrabold">+10 créditos</strong> foram adicionados instantaneamente à sua conta!
            </p>
            <div className="mt-6 px-4 py-2 bg-green-500/5 border border-green-500/15 rounded-xl">
              <p className="text-xs text-zinc-400">Novo saldo de anúncios: <strong className="text-green-400 font-black">{(userProfile?.credits || 0)} Créditos</strong></p>
            </div>
            <button
              onClick={handleClose}
              className="mt-8 w-full bg-zinc-900 hover:bg-zinc-800 text-white font-black py-3.5 rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer"
            >
              Começar a Anunciar
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600/10 border border-blue-500/20 p-2.5 rounded-2xl text-blue-500">
                <Coins size={24} />
              </div>
              <div>
                <h3 className="text-lg font-black uppercase text-white tracking-tight">Recarga de Créditos</h3>
                <p className="text-xs text-zinc-500">Adquira pacotes para anunciar seus veículos</p>
              </div>
            </div>

            {/* Package details */}
            <div className="bg-zinc-900/40 border border-zinc-900 p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-[10px] text-blue-400 font-extrabold uppercase tracking-widest">PROMOÇÃO</span>
                <h4 className="text-base font-black text-white mt-0.5">10 Anúncios de Veículos</h4>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-zinc-500 line-through">R$ 19,90</span>
                <p className="text-lg font-black text-blue-500">R$ 9,99</p>
              </div>
            </div>

            {/* Current Credits Balance */}
            <div className="text-center py-2 bg-blue-500/5 border border-blue-500/10 rounded-xl">
              <span className="text-xs text-zinc-400">Seu saldo atual: </span>
              <strong className="text-blue-400 font-black ml-1 text-sm">{userProfile?.credits || 0} Créditos</strong>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 p-3.5 rounded-xl flex gap-3 text-red-400 text-xs leading-relaxed">
                <AlertTriangle size={18} className="shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {!paymentData ? (
              /* Step 1: Input CPF to generate Pix */
              <form onSubmit={handleGeneratePix} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs text-zinc-400 font-bold uppercase tracking-wider block">Seu CPF (Requerido pelo Pix)</label>
                  <input
                    type="text"
                    required
                    placeholder="000.000.000-00"
                    value={cpf}
                    onChange={handleCpfChange}
                    className="w-full bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-600 px-4 py-3.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all font-mono"
                  />
                  <span className="text-[10px] text-zinc-500 block">Seus dados estão protegidos sob conexão criptografada segura.</span>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-zinc-800 text-white py-3.5 rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer transition-all shadow-lg shadow-blue-600/10 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      <span>Gerando Pix...</span>
                    </>
                  ) : (
                    <>
                      <Coins size={14} />
                      <span>Gerar Pix de R$ 9,99</span>
                    </>
                  )}
                </button>
              </form>
            ) : (
              /* Step 2: Show QR Code and copy-paste details */
              <div className="space-y-5 animate-scale-up">
                <div className="flex flex-col items-center justify-center gap-4 py-1">
                  
                  {/* Real Dynamic QR Code image */}
                  <div className="bg-white p-3.5 rounded-2xl shadow-xl shadow-blue-500/5 border border-zinc-250 flex items-center justify-center">
                    {paymentData.qrCodeBase64 ? (
                      <img 
                        src={`data:image/png;base64,${paymentData.qrCodeBase64}`} 
                        alt="QR Code Pix Mercado Pago"
                        className="w-44 h-44 object-contain"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-44 h-44 flex flex-col items-center justify-center bg-zinc-50 text-zinc-400 text-[10px] font-bold">
                        <QrCode size={40} className="animate-pulse mb-2 text-zinc-400" />
                        Aguardando Imagem...
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full">
                    <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping"></span>
                    <span className="text-[10px] text-blue-400 font-extrabold uppercase tracking-wider">Aguardando pagamento via Pix</span>
                  </div>

                  <p className="text-xs text-zinc-400 text-center max-w-xs leading-relaxed">
                    Abra o app do seu banco, selecione a opção <strong>Pix Copia e Cola</strong> ou aponte a câmera para o QR Code acima.
                  </p>
                </div>

                {/* Copia e Cola payload input */}
                <div className="space-y-2">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">Código Pix (Copia e Cola)</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      readOnly
                      value={paymentData.qrCode}
                      className="flex-1 bg-zinc-900 border border-zinc-850 px-3.5 py-2.5 rounded-xl text-xs text-zinc-400 font-mono select-all truncate outline-none"
                    />
                    <button 
                      onClick={handleCopyPixCode}
                      className="bg-blue-600 hover:bg-blue-750 text-white px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      {copied ? <Check size={14} /> : <Copy size={14} />}
                      <span>{copied ? 'Copiado!' : 'Copiar'}</span>
                    </button>
                  </div>
                </div>

                {/* Additional Payment Info */}
                <div className="pt-2 flex flex-col gap-2">
                  {paymentData.ticketUrl && (
                    <a
                      href={paymentData.ticketUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-300 hover:text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
                    >
                      <span>Visualizar Ticket no Mercado Pago</span>
                      <ExternalLink size={12} />
                    </a>
                  )}

                  <button
                    onClick={() => {
                      if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
                      setPaymentData(null);
                    }}
                    className="w-full text-zinc-500 hover:text-zinc-300 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-colors"
                  >
                    Alterar CPF / Recomeçar
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
