import React, { useState, useEffect } from 'react';
import { signInWithGoogle, auth, db } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Car, ShieldCheck, Mail, LogIn, UserPlus, Lock, User, Phone, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

export const Login = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  // Navigation redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [forceShowForm, setForceShowForm] = useState(false);
  const [authTimeout, setAuthTimeout] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');

  useEffect(() => {
    if (loading && !forceShowForm) {
      const timer = setTimeout(() => {
        setAuthTimeout(true);
      }, 9000);
      return () => clearTimeout(timer);
    }
  }, [loading, forceShowForm]);

  const handleGoogleLogin = async () => {
    setError(null);
    try {
      const result = await signInWithGoogle();
      const user = result.user;
      
      // Save/check profile on google sign in
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        name: user.displayName || '',
        email: user.email || '',
        phone: user.phoneNumber || '',
        city: '',
        updatedAt: serverTimestamp()
      }, { merge: true });

    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/popup-blocked' || err.code === 'auth/popup-closed-by-user' || err.message?.includes('popup')) {
        setError('O navegador do celular bloqueou temporariamente a janela pop-up do Google. Sugerimos usar a opção de "E-mail e Senha" para cadastrar/entrar de forma imediata e 100% estável!');
      } else {
        setError('Erro ao fazer login com Google. Tente entrar digitando seu E-mail e Senha.');
      }
    }
  };

  const handleEmailAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      if (activeTab === 'login') {
        // Sign In
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        // Validation
        if (!name.trim()) throw new Error('Por favor, informe seu nome completo.');
        if (!phone.trim()) throw new Error('Por favor, informe um telefone/WhatsApp.');
        if (password.length < 6) throw new Error('A senha deve ter no mínimo 6 caracteres.');

        // Sign Up
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const newUser = userCredential.user;

        // Set Display name
        await updateProfile(newUser, { displayName: name });

        // Create database document in /users
        await setDoc(doc(db, 'users', newUser.uid), {
          uid: newUser.uid,
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          city: city.trim(),
          createdAt: serverTimestamp()
        });
      }
    } catch (err: any) {
      console.error(err);
      let errMsg = 'Ocorreu um erro. Tente novamente.';
      if (err.code === 'auth/user-not-found') errMsg = 'Usuário não encontrado.';
      else if (err.code === 'auth/wrong-password') errMsg = 'Senha incorreta. Verifique os dados ou redefina.';
      else if (err.code === 'auth/email-already-in-use') errMsg = 'Este e-mail já está cadastrado no seu projeto Firebase compartilhado. Você pode entrar diretamente usando a aba "Entrar" com sua senha existente!';
      else if (err.code === 'auth/invalid-email') errMsg = 'E-mail inválido.';
      else if (err.message) errMsg = err.message;
      setError(errMsg);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading && !forceShowForm) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-white text-center">
        <div className="max-w-md w-full bg-zinc-950 rounded-3xl p-8 sm:p-10 border border-zinc-900 shadow-2xl shadow-blue-500/5 flex flex-col items-center gap-6">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-900/30 animate-pulse">
            <Car className="text-white animate-bounce" size={32} />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight">Localiza Veículos</h2>
            <p className="text-zinc-400 text-xs sm:text-sm mt-2 leading-relaxed max-w-xs mx-auto">Verificando suas credenciais de acesso com segurança...</p>
          </div>
          
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mt-2"></div>
          
          {authTimeout && (
            <div className="mt-4 pt-4 border-t border-zinc-900 w-full animate-fade-in space-y-3">
              <p className="text-[11px] text-zinc-500 leading-normal">Detecção: Sua conexão móvel móvel 3G/4G/5G está demorando para completar a verificação segura do Firebase.</p>
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => window.location.reload()}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer"
                >
                  Recarregar Conexão
                </button>
                <button 
                  onClick={() => setForceShowForm(true)}
                  className="w-full bg-zinc-905 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider cursor-pointer transition-colors"
                >
                  Entrar mesmo assim (E-mail e Senha)
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 sm:p-6 text-white pt-24 pb-12">
      <div className="max-w-md w-full bg-zinc-950 rounded-3xl shadow-2xl shadow-blue-500/5 p-6 sm:p-10 border border-zinc-900 text-center">
        
        {/* Logo */}
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-900/30 rotate-3 hover:rotate-0 transition-transform">
          <Car className="text-white" size={32} />
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-white mb-2 tracking-tight">
          {activeTab === 'login' ? 'Área de Acesso' : 'Crie sua Conta'}
        </h1>
        <p className="text-sm text-zinc-400 mb-8 max-w-sm mx-auto">
          {activeTab === 'login' 
            ? 'Faça login para anunciar seus veículos e gerenciar seus classificados.' 
            : 'Crie sua conta em segundos para publicar seus anúncios grátis.'}
        </p>

        {/* Tab Buttons */}
        <div className="flex bg-zinc-900/80 p-1.5 rounded-2xl border border-zinc-850 mb-6 sm:mb-8">
          <button
            type="button"
            onClick={() => { setActiveTab('login'); setError(null); }}
            className={`flex-1 py-2 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'login' ? 'bg-blue-600 text-white shadow' : 'text-zinc-400 hover:text-white'}`}
          >
            <LogIn size={16} />
            Entrar
          </button>
          <button
            type="button"
            onClick={() => { setActiveTab('register'); setError(null); }}
            className={`flex-1 py-2 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 ${activeTab === 'register' ? 'bg-blue-600 text-white shadow' : 'text-zinc-400 hover:text-white'}`}
          >
            <UserPlus size={16} />
            Cadastrar-se
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-950/20 border border-red-900/50 rounded-2xl text-red-400 text-xs sm:text-sm font-medium text-left animate-fade-in">
            {error}
          </div>
        )}

        <form onSubmit={handleEmailAction} className="space-y-4 text-left">
          {activeTab === 'register' && (
            <>
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">Nome Completo</label>
                <div className="relative">
                  <User size={18} className="absolute left-4 top-3.5 text-zinc-500" />
                  <input
                    required
                    type="text"
                    placeholder="Seu nome"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-zinc-600"
                  />
                </div>
              </div>

              {/* Phone/WhatsApp */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">WhatsApp / Celular</label>
                <div className="relative">
                  <Phone size={18} className="absolute left-4 top-3.5 text-zinc-500" />
                  <input
                    required
                    type="tel"
                    placeholder="(00) 99999-9999"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-zinc-600"
                  />
                </div>
              </div>

              {/* City */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">Cidade / Estado</label>
                <div className="relative">
                  <MapPin size={18} className="absolute left-4 top-3.5 text-zinc-500" />
                  <input
                    required
                    type="text"
                    placeholder="Ex: São Paulo - SP"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-zinc-600"
                  />
                </div>
              </div>
            </>
          )}

          {/* Email */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">Endereço de E-mail</label>
            <div className="relative">
              <Mail size={18} className="absolute left-4 top-3.5 text-zinc-500" />
              <input
                required
                type="email"
                placeholder="exemplo@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-zinc-600"
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-wider">Senha Secreta</label>
            <div className="relative">
              <Lock size={18} className="absolute left-4 top-3.5 text-zinc-500" />
              <input
                required
                type="password"
                placeholder="••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-11 pr-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors placeholder:text-zinc-600"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-4 mt-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white rounded-xl text-sm font-extrabold uppercase tracking-widest transition-all shadow-lg shadow-blue-500/10 flex items-center justify-center gap-2"
          >
            {submitting ? 'Aguarde...' : activeTab === 'login' ? 'Entrar no Painel' : 'Criar minha Conta'}
          </button>
        </form>

        {/* Divider */}
        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-zinc-900"></div></div>
          <span className="relative bg-zinc-950 px-3 text-xs font-bold text-zinc-500 uppercase tracking-widest">ou</span>
        </div>

        {/* Google Login Button */}
        <button 
          onClick={handleGoogleLogin}
          className="w-full flex items-center justify-center gap-3 bg-zinc-900 border border-zinc-850 hover:border-zinc-800 py-3.5 rounded-xl font-bold text-sm text-white hover:bg-zinc-850 transition-all"
        >
          <svg className="w-4 h-4 mr-1 text-red-500" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.24 10.285V13.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.866-3.577-7.866-8s3.536-8 7.866-8c2.46 0 4.105 1.025 5.047 1.926l2.427-2.334C17.955 2.192 15.34 1 12.24 1c-6.075 0-11 4.925-11 11s4.925 11 11 11c6.34 0 10.564-4.455 10.564-10.75 0-.72-.075-1.275-.175-1.63H12.24z"/>
          </svg>
          Acessar com Google
        </button>

        <p className="mt-8 text-xs text-zinc-600 uppercase tracking-widest font-black">
          <span className="text-zinc-500 text-xs">L</span>ocaliza <span className="text-zinc-500 text-xs">V</span>eículos
        </p>
      </div>
    </div>
  );
};
