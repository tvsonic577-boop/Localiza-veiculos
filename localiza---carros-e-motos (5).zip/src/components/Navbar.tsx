import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Home, Car, Bike, Settings, LogIn, User } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { CreditsModal } from './CreditsModal';

export const Navbar = () => {
  const { user, userProfile, isAdmin, refreshProfile } = useAuth();
  const [isCreditsOpen, setIsCreditsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-black/85 backdrop-blur-md border-b border-zinc-900 px-4 md:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-1 sm:gap-2">
          <div className="bg-blue-650 p-1 sm:p-1.5 rounded-lg shadow-inner shrink-0">
            <Car className="text-white" size={18} />
          </div>
          <span className="text-xs xs:text-sm sm:text-xl font-black tracking-tighter uppercase text-white whitespace-nowrap">
            <span className="text-sm xs:text-base sm:text-2xl font-black">L</span>ocaliza <span className="text-blue-500"><span className="text-sm xs:text-base sm:text-2xl font-black">V</span>eículos</span>
          </span>
        </Link>
        
        <div className="flex items-center gap-1.5 sm:gap-3 md:gap-6">
          <div className="hidden sm:flex items-center gap-3 md:gap-6">
            <Link to="/" className="text-xs md:text-sm text-zinc-400 hover:text-white transition-colors font-semibold uppercase tracking-wide">Início</Link>
            <Link to="/?type=car" className="text-xs md:text-sm text-zinc-400 hover:text-white transition-colors font-semibold uppercase tracking-wide">Carros</Link>
            <Link to="/?type=motorcycle" className="text-xs md:text-sm text-zinc-400 hover:text-white transition-colors font-semibold uppercase tracking-wide">Motos</Link>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-3">
          {user ? (
            <a 
              href="#credits"
              onClick={(e) => {
                e.preventDefault();
                setIsCreditsOpen(true);
              }}
              className="text-[8px] sm:text-xs uppercase tracking-widest font-black text-blue-500 hover:text-white border border-blue-500/30 hover:border-blue-500 hover:bg-blue-500/10 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full transition-all duration-300 whitespace-nowrap cursor-pointer"
            >
              Anuncie<span className="hidden xs:inline sm:inline"> ({userProfile?.credits ?? 0} Créditos)</span>
              <span className="xs:inline sm:hidden"> ({userProfile?.credits ?? 0} Cr)</span>
            </a>
          ) : (
            <Link 
              to="/login"
              className="text-[8px] sm:text-xs uppercase tracking-widest font-black text-blue-500 hover:text-white border border-blue-500/30 hover:border-blue-500 hover:bg-blue-500/10 px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-full transition-all duration-300 whitespace-nowrap"
            >
              Anuncie<span className="hidden xs:inline sm:inline"> - R$ 9,99</span>
            </Link>
          )}
          {user ? (
            <Link to="/dashboard" className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-100 border border-zinc-800 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-[10px] sm:text-sm font-semibold transition-all">
              <Settings size={14} className="sm:size-[18px]" />
              <span>{isAdmin ? 'Painel ADM' : 'Meu Painel'}</span>
            </Link>
          ) : (
            <Link to="/login" className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-3 sm:px-5 py-1.5 sm:py-2 rounded-full text-[10px] sm:text-sm font-semibold shadow-lg shadow-blue-500/10 transition-all">
              <LogIn size={14} className="sm:size-[18px]" />
              Acesso
            </Link>
          )}
        </div>
      </div>
      {user && (
        <CreditsModal 
          isOpen={isCreditsOpen} 
          onClose={() => setIsCreditsOpen(false)} 
          user={user}
          userProfile={userProfile}
          refreshProfile={refreshProfile}
        />
      )}
    </nav>
  );
};
