import React, { useState } from 'react';
import { X, Coins, Copy, Check, ExternalLink, QrCode } from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface CreditsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  userProfile: any;
  refreshProfile: () => Promise<void>;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({
  isOpen,
  onClose,
  user,
  userProfile,
  refreshProfile,
}) => {
  const [copied, setCopied] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const pixKey = "financeiro@localizaveiculos.com.br";
  // Simulated PIX Copy & Paste payload
  const pixCopyPaste = "00020101021226830014br.gov.bcb.pix2561api.mercadopago.com/v1/payments/7748929110/ticket/9.99/localizaveiculos";

  const handleCopyKey = () => {
    navigator.clipboard.writeText(pixKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulatePayment = async () => {
    if (!user) return;
    setSimulating(true);
    try {
      const currentCredits = userProfile?.credits || 0;
      const newCredits = currentCredits + 10;
      
      // Update in Firestore
      await setDoc(doc(db, 'users', user.uid), { credits: newCredits }, { merge: true });
      await refreshProfile();
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 3000);
    } catch (error) {
      console.error("Error updating credits:", error);
      alert("Houve um erro ao creditar sua recarga. Tente novamente.");
    } finally {
      setSimulating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-900 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        
        {/* Glow effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1.5 rounded-full hover:bg-zinc-900 transition-colors cursor-pointer"
        >
          <X size={20} />
        </button>

        {success ? (
          <div className="flex flex-col items-center justify-center py-8 text-center animate-scale-up">
            <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 text-green-500 rounded-full flex items-center justify-center mb-6 animate-bounce">
              <Coins size={36} />
            </div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tight">Recarga Confirmada!</h3>
            <p className="text-zinc-400 text-sm mt-3 max-w-xs mx-auto">
              Seu pagamento de R$ 9,99 foi identificado pelo sistema. <br />
              <strong className="text-green-400 font-extrabold">+10 créditos</strong> adicionados à sua conta com sucesso!
            </p>
            <p className="text-zinc-500 text-xs mt-6">Seu novo saldo é de {(userProfile?.credits || 0)} créditos.</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600/10 border border-blue-500/20 p-2.5 rounded-2xl text-blue-500">
                <Coins size={24} />
              </div>
              <div>
                <h3 className="text-lg font-black uppercase text-white tracking-tight">Recarga de Créditos</h3>
                <p className="text-xs text-zinc-500">Adquira pacotes para anunciar seus veículos</p>
              </div>
            </div>

            {/* Price Card */}
            <div className="bg-zinc-900/40 border border-zinc-900 p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs text-zinc-400 font-bold uppercase tracking-wider">Pacote Promocional</span>
                <h4 className="text-xl font-black text-white mt-1">10 Anúncios Publicados</h4>
              </div>
              <div className="text-right">
                <span className="text-xs text-zinc-500 line-through">R$ 19,90</span>
                <p className="text-xl font-black text-blue-500">R$ 9,99</p>
              </div>
            </div>

            {/* Current Balance */}
            <div className="text-center py-2 bg-blue-500/5 border border-blue-500/10 rounded-xl">
              <span className="text-xs text-zinc-400">Seu saldo atual: </span>
              <strong className="text-blue-400 font-black ml-1 text-sm">{userProfile?.credits || 0} Crédito(s)</strong>
            </div>

            {/* Pix Instructions */}
            <div className="space-y-4">
              <div className="flex flex-col items-center justify-center gap-4 py-2">
                {/* QR Code Container */}
                <div className="bg-white p-3 rounded-2xl shadow-xl shadow-blue-500/5 border border-zinc-800">
                  {/* Styled Pix QR Code using standard HTML structure for universal compatibility */}
                  <div className="w-40 h-40 flex flex-col items-center justify-center bg-gray-50 border border-gray-200 rounded-xl relative">
                    <QrCode className="text-black" size={100} />
                    <span className="text-[9px] font-black uppercase text-zinc-600 tracking-wider mt-1">PIX SEGURO</span>
                    <div className="absolute inset-0 flex items-center justify-center bg-black/5 rounded-xl pointer-events-none"></div>
                  </div>
                </div>
                <p className="text-xs text-zinc-400 text-center max-w-xs">
                  Abra o app do seu banco, selecione a opção <strong>Pix Copia e Cola</strong> ou aponte a câmera para o QR Code acima.
                </p>
              </div>

              {/* Pix Key Actions */}
              <div className="space-y-2">
                <label className="text-xs text-zinc-400 font-bold uppercase tracking-wider block">Chave Pix (E-mail)</label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-zinc-900 border border-zinc-850 px-3.5 py-2.5 rounded-xl text-xs text-zinc-300 font-mono select-all truncate">
                    {pixKey}
                  </div>
                  <button 
                    onClick={handleCopyKey}
                    className="bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-300 hover:text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                    <span>{copied ? 'Copiado' : 'Copiar'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-2">
              {/* Payment simulator */}
              <button
                onClick={handleSimulatePayment}
                disabled={simulating}
                className="w-full bg-blue-600 hover:bg-blue-750 disabled:bg-zinc-800 text-white py-3 rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer transition-all shadow-lg shadow-blue-600/10 flex items-center justify-center gap-2"
              >
                {simulating ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                ) : (
                  <>
                    <Coins size={14} />
                    <span>Confirmar Pagamento Pix (Simulador)</span>
                  </>
                )}
              </button>

              {/* Real Checkout Link */}
              <a
                href="https://mpago.la/1anBvFU"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-300 hover:text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
              >
                <span>Pagar via Mercado Pago</span>
                <ExternalLink size={12} />
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
