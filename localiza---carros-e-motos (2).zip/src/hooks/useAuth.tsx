import React, { useState, useEffect, createContext, useContext } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  userProfile: any | null;
  loading: boolean;
  isAdmin: boolean;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({ 
  user: null, 
  userProfile: null, 
  loading: true, 
  isAdmin: false,
  refreshProfile: async () => {}
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<any | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (uid: string, currentUserObj: User) => {
    try {
      const uDoc = await getDoc(doc(db, 'users', uid));
      if (uDoc.exists()) {
        setUserProfile(uDoc.data());
      } else {
        const initialProfile = {
          name: currentUserObj.displayName || currentUserObj.email?.split('@')[0] || 'Anunciante',
          email: currentUserObj.email || '',
          phone: '',
          city: '',
          uid: uid,
          createdAt: new Date().toISOString()
        };
        // Auto-create profile in this isolated database
        await setDoc(doc(db, 'users', uid), initialProfile);
        setUserProfile(initialProfile);
      }
    } catch (e) {
      console.error("Error reading profile:", e);
      setUserProfile(null);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.uid, user);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const adminDoc = await getDoc(doc(db, 'admins', currentUser.uid));
        setIsAdmin(adminDoc.exists() || currentUser.email === 'tvsonic577@gmail.com');
        await fetchProfile(currentUser.uid, currentUser);
      } else {
        setIsAdmin(false);
        setUserProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider value={{ user, userProfile, loading, isAdmin, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
