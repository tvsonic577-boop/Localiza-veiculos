import React from 'react';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton = () => {
  const phoneNumber = "5562996346075"; 
  const message = encodeURIComponent("Olá! Tenho algumas dúvidas e gostaria de mais informações.");
  const url = `https://wa.me/${phoneNumber}?text=${message}`;

  return (
    <a 
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 right-5 z-50 bg-[#25D366] text-white p-3.5 sm:px-5 sm:py-3 rounded-full shadow-2xl hover:scale-110 transition-all active:scale-95 flex items-center gap-2 font-bold uppercase tracking-wider text-sm shadow-emerald-950/20"
      aria-label="Dúvidas WhatsApp"
      id="whatsapp-floating-button"
    >
      <MessageCircle size={22} />
      <span className="hidden sm:inline">Dúvidas</span>
    </a>
  );
};
