export type VehicleType = 'car' | 'motorcycle';

export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  description: string;
  type: VehicleType;
  images: string[];
  createdAt: any; 
  ownerId: string; 
  city?: string;
  phone?: string;
  advertiserName?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  interestedIn?: string; 
  createdAt: any;
}
