import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Vehicle, VehicleType } from '../types';
import { VehicleCard } from '../components/VehicleCard';
import { Search, SlidersHorizontal, Car, Bike, LayoutGrid, X, ChevronLeft, ChevronRight, MapPin, Phone, User, MessageSquare } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { formatCurrency } from '../lib/utils';

export const Home = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Custom Modal & Lightbox States
  const [selectedVehicleForDetails, setSelectedVehicleForDetails] = useState<Vehicle | null>(null);
  const [lightboxVehicle, setLightboxVehicle] = useState<Vehicle | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);
  const [detailCarouselIndex, setDetailCarouselIndex] = useState<number>(0);

  const activeType = searchParams.get('type') as VehicleType | null;

  useEffect(() => {
    let q = query(collection(db, 'vehicles'), orderBy('createdAt', 'desc'));
    
    if (activeType) {
      q = query(collection(db, 'vehicles'), where('type', '==', activeType), orderBy('createdAt', 'desc'));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Vehicle));
      setVehicles(data);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching vehicles:", error);
      setLoading(false);
    });

    return unsubscribe;
  }, [activeType]);

  useEffect(() => {
    const vehicleIdParam = searchParams.get('vehicle');
    if (vehicleIdParam && vehicles.length > 0) {
      if (!selectedVehicleForDetails || selectedVehicleForDetails.id !== vehicleIdParam) {
        const found = vehicles.find(v => v.id === vehicleIdParam);
        if (found) {
          setSelectedVehicleForDetails(found);
          setDetailCarouselIndex(0);
        }
      }
    } else if (!vehicleIdParam && selectedVehicleForDetails) {
      setSelectedVehicleForDetails(null);
    }
  }, [vehicles, searchParams, selectedVehicleForDetails]);

  const filteredVehicles = vehicles.filter(v => 
    v.brand.toLowerCase().includes(search.toLowerCase()) || 
    v.model.toLowerCase().includes(search.toLowerCase())
  );

  // Lightbox navigation helpers
  const handleNextLightboxImage = () => {
    if (!lightboxVehicle) return;
    const total = lightboxVehicle.images?.length || 0;
    setLightboxIndex(prev => (prev === total - 1 ? 0 : prev + 1));
  };

  const handlePrevLightboxImage = () => {
    if (!lightboxVehicle) return;
    const total = lightboxVehicle.images?.length || 0;
    setLightboxIndex(prev => (prev === 0 ? total - 1 : prev - 1));
  };

  // Details carousel helpers
  const handleNextDetailImage = (total: number) => {
    setDetailCarouselIndex(prev => (prev === total - 1 ? 0 : prev + 1));
  };

  const handlePrevDetailImage = (total: number) => {
    setDetailCarouselIndex(prev => (prev === 0 ? total - 1 : prev - 1));
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Hero Section */}
      <section className="relative h-[60vh] sm:h-[80vh] min-h-[420px] sm:min-h-[500px] flex items-center justify-center overflow-hidden bg-black">
        {/* Background Image / Porsche/luxury car showroom */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1542282088-fe8426682b8f?auto=format&fit=crop&q=80&w=1920" 
            alt="Porsche Vermelho"
            className="w-full h-full object-cover object-center opacity-65"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/85" />
        </div>



        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="text-3xl sm:text-5xl md:text-8xl font-black tracking-tighter text-white mb-4 sm:mb-6 uppercase">
              <span className="text-4xl sm:text-6xl md:text-9xl">L</span>ocaliza <span className="text-blue-500"><span className="text-4xl sm:text-6xl md:text-9xl">V</span>eículos</span>
            </h1>
            <p className="text-base sm:text-xl md:text-2xl text-zinc-300 font-medium max-w-3xl mx-auto leading-relaxed mb-8 sm:mb-10 px-2 drop-shadow-sm">
              Sua próxima conquista começa aqui. <br className="hidden md:block" />
              Onde a paixão por rodas encontra o melhor negócio.
            </p>
            
            <div className="flex flex-col md:flex-row items-center justify-center gap-4">
              <a 
                href="#estoque" 
                className="bg-blue-600 text-white px-8 md:px-10 py-3.5 md:py-4 rounded-2xl font-bold text-base md:text-lg shadow-2xl shadow-blue-500/20 hover:bg-blue-700 hover:-translate-y-1 transition-all w-full md:w-auto"
              >
                Ver Estoque Completo
              </a>
              <button 
                onClick={() => document.getElementById('search-input')?.focus()}
                className="bg-zinc-900/80 backdrop-blur text-white px-8 md:px-10 py-3.5 md:py-4 rounded-2xl font-bold text-base md:text-lg border border-zinc-800 hover:bg-zinc-850 transition-all w-full md:w-auto"
              >
                Pesquisar Modelo
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Filter & Search Bar */}
      <section id="estoque" className="py-4 md:py-6 px-4 md:px-8 border-b border-zinc-900 bg-black sticky top-[58px] sm:top-[72px] z-30 shadow-md shadow-black/15 animate-fade-in">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Search Bar */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none text-zinc-500 group-focus-within:text-blue-500 transition-colors">
                <Search size={18} />
              </div>
              <input 
                id="search-input"
                type="text"
                placeholder="Busque por marca ou modelo (ex: Ferrari, Yamaha...)"
                className="w-full bg-zinc-900/50 border-zinc-800 border text-white placeholder-zinc-500 rounded-xl py-3 pl-12 pr-6 text-sm focus:ring-4 focus:ring-zinc-900/40 focus:bg-zinc-900/90 transition-all outline-none"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            {/* Category Filter Chips */}
            <div className="flex justify-center gap-2">
              <button 
                onClick={() => setSearchParams({})}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 duration-200 ${!activeType ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:bg-zinc-850 hover:text-white'}`}
              >
                <LayoutGrid size={12} />
                <span>Todos</span>
              </button>
              <button 
                onClick={() => setSearchParams({ type: 'car' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 duration-200 ${activeType === 'car' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:bg-zinc-850 hover:text-white'}`}
              >
                <Car size={12} />
                <span>Carros</span>
              </button>
              <button 
                onClick={() => setSearchParams({ type: 'motorcycle' })}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 duration-200 ${activeType === 'motorcycle' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:bg-zinc-850 hover:text-white'}`}
              >
                <Bike size={12} />
                <span>Motos</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Grid Section */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-zinc-400 font-medium">Carregando nosso estoque...</p>
          </div>
        ) : filteredVehicles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredVehicles.map(vehicle => (
              <VehicleCard 
                key={vehicle.id} 
                vehicle={vehicle} 
                onViewDetails={(v) => {
                  setSelectedVehicleForDetails(v);
                  setDetailCarouselIndex(0);
                  setSearchParams(prev => {
                    const next = new URLSearchParams(prev);
                    next.set('vehicle', v.id);
                    return next;
                  });
                }}
                onViewImage={(v, index) => {
                  setLightboxVehicle(v);
                  setLightboxIndex(index || 0);
                }}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-24 bg-zinc-950 rounded-3xl border border-dashed border-zinc-800">
            <div className="bg-zinc-900 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search className="text-zinc-650" size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Nenhum veículo encontrado</h3>
            <p className="text-zinc-400">Tente ajustar sua busca ou filtros para encontrar o que procura.</p>
          </div>
        )}
      </main>

      {/* Modals & Lightbox rendering */}
      <AnimatePresence>
        {/* Fullscreen Interactive Lightbox Modal */}
        {lightboxVehicle && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-4 select-none"
            onClick={() => setLightboxVehicle(null)}
          >
            {/* Close Button X */}
            <button 
              onClick={() => setLightboxVehicle(null)}
              className="absolute top-6 right-6 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-white p-3 rounded-full transition-all hover:scale-105 z-10"
              title="Fechar"
            >
              <X size={24} />
            </button>

            {/* Header info */}
            <div className="absolute top-6 left-6 text-left">
              <p className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest">Visualização em Alta</p>
              <h2 className="text-xl font-black uppercase text-white tracking-tight">{lightboxVehicle.brand} <span className="font-normal text-zinc-400 normal-case">{lightboxVehicle.model}</span></h2>
            </div>

            {/* Slider container */}
            <div className="relative max-w-5xl w-full aspect-video flex items-center justify-center" onClick={e => e.stopPropagation()}>
              <img 
                src={lightboxVehicle.images[lightboxIndex]} 
                alt={`${lightboxVehicle.brand} ${lightboxVehicle.model}`} 
                className="max-h-[80vh] max-w-full object-contain rounded-xl shadow-2xl border border-zinc-900 select-none pointer-events-none"
              />

              {/* Slider Arrows */}
              {lightboxVehicle.images.length > 1 && (
                <>
                  <button 
                    onClick={handlePrevLightboxImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/70 hover:bg-black/95 text-white p-3 rounded-full border border-zinc-800 transition-colors"
                  >
                    <ChevronLeft size={24} />
                  </button>
                  <button 
                    onClick={handleNextLightboxImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/70 hover:bg-black/95 text-white p-3 rounded-full border border-zinc-800 transition-colors"
                  >
                    <ChevronRight size={24} />
                  </button>
                </>
              )}
            </div>

            {/* Bottom slides indicator */}
            <div className="absolute bottom-6 bg-zinc-950/80 border border-zinc-850 px-4 py-1.5 rounded-full text-xs text-zinc-400 font-bold">
              {lightboxIndex + 1} / {lightboxVehicle.images.length}
            </div>
          </motion.div>
        )}

        {/* Vehicle Details & Specifications Modal with Advertiser Info */}
        {selectedVehicleForDetails && (
          <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/75 backdrop-blur-sm"
              onClick={() => {
                setSelectedVehicleForDetails(null);
                setSearchParams(prev => {
                  const next = new URLSearchParams(prev);
                  next.delete('vehicle');
                  return next;
                });
              }}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-zinc-950 border border-zinc-900 w-full max-w-4xl rounded-2xl md:rounded-3xl overflow-hidden shadow-2xl z-10 flex flex-col max-h-[95vh] md:max-h-[90vh]"
            >
              <div className="p-4 sm:p-6 border-b border-zinc-900 flex items-center justify-between bg-zinc-950 sticky top-0 z-20">
                <div>
                  <span className="text-[9px] sm:text-[10px] text-blue-500 uppercase font-black tracking-widest">Especificações do Veículo</span>
                  <h2 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight">{selectedVehicleForDetails.brand} {selectedVehicleForDetails.model}</h2>
                </div>
                <button 
                  onClick={() => {
                    setSelectedVehicleForDetails(null);
                    setSearchParams(prev => {
                      const next = new URLSearchParams(prev);
                      next.delete('vehicle');
                      return next;
                    });
                  }}
                  className="p-2 hover:bg-zinc-900 rounded-full text-zinc-400 hover:text-white border border-zinc-900 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-4 sm:p-6 md:p-8 space-y-5 sm:space-y-6 overflow-y-auto flex-1">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                  {/* Left Column: Image Gallery Carousel */}
                  <div className="space-y-4">
                    <div className="relative aspect-video rounded-xl sm:rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-850 group">
                      <img 
                        src={selectedVehicleForDetails.images[detailCarouselIndex]} 
                        alt={selectedVehicleForDetails.model}
                        className="w-full h-full object-cover"
                      />
                      {/* Nav Arrows */}
                      {selectedVehicleForDetails.images.length > 1 && (
                        <>
                          <button 
                            onClick={() => handlePrevDetailImage(selectedVehicleForDetails.images.length)}
                            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/60 text-white p-2 rounded-full hover:bg-black/80 transition-colors"
                          >
                            <ChevronLeft size={16} />
                          </button>
                          <button 
                            onClick={() => handleNextDetailImage(selectedVehicleForDetails.images.length)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/60 text-white p-2 rounded-full hover:bg-black/80 transition-colors"
                          >
                            <ChevronRight size={16} />
                          </button>
                        </>
                      )}
                      
                      <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur border border-zinc-800 text-zinc-300 px-2 py-0.5 rounded text-[10px] font-bold">
                        {detailCarouselIndex + 1} / {selectedVehicleForDetails.images.length}
                      </div>
                    </div>

                    {/* Small Thumbnails */}
                    {selectedVehicleForDetails.images.length > 1 && (
                      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
                        {selectedVehicleForDetails.images.map((imgUrl, idx) => (
                          <button 
                            key={idx}
                            onClick={() => setDetailCarouselIndex(idx)}
                            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden border-2 shrink-0 transition-all ${detailCarouselIndex === idx ? 'border-blue-500 scale-105' : 'border-zinc-850 opacity-60 hover:opacity-100'}`}
                          >
                            <img src={imgUrl} className="w-full h-full object-cover" alt="thumbnail" />
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Right Column: Spec List & Contact details */}
                  <div className="flex flex-col justify-between space-y-6">
                    <div className="space-y-5">
                      <div className="grid grid-cols-2 gap-2.5 sm:gap-4">
                        <div className="bg-zinc-900/50 p-2.5 sm:p-3.5 border border-zinc-900 rounded-xl">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Marca</p>
                          <p className="font-extrabold text-white text-sm sm:text-base mt-0.5">{selectedVehicleForDetails.brand}</p>
                        </div>
                        <div className="bg-zinc-900/50 p-2.5 sm:p-3.5 border border-zinc-900 rounded-xl">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Modelo</p>
                          <p className="font-extrabold text-white text-sm sm:text-base mt-0.5">{selectedVehicleForDetails.model}</p>
                        </div>
                        <div className="bg-zinc-900/50 p-2.5 sm:p-3.5 border border-zinc-900 rounded-xl">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Ano Modelo</p>
                          <p className="font-extrabold text-white text-sm sm:text-base mt-0.5">{selectedVehicleForDetails.year}</p>
                        </div>
                        <div className="bg-zinc-900/50 p-2.5 sm:p-3.5 border border-zinc-900 rounded-xl">
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Combustível / Tipo</p>
                          <p className="font-extrabold text-white text-sm sm:text-base mt-0.5 uppercase">{selectedVehicleForDetails.type === 'car' ? 'Carro' : 'Moto'}</p>
                        </div>
                      </div>

                      {/* Decription */}
                      <div className="space-y-1.5 p-1">
                        <p className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-wider">Descrição Detalhada</p>
                        <p className="text-zinc-300 text-sm leading-relaxed whitespace-pre-line bg-zinc-900/20 border border-zinc-900/40 p-4 rounded-xl">
                          {selectedVehicleForDetails.description || 'Nenhum detalhe adicional inserido.'}
                        </p>
                      </div>

                      {/* Advertiser info & Local */}
                      <div className="border-t border-zinc-900 pt-5 space-y-3">
                        <h4 className="text-xs font-black uppercase text-zinc-400 tracking-wider">Informações de Contato</h4>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                          <div className="flex items-center gap-2.5 text-zinc-300">
                            <div className="p-2 bg-zinc-900 rounded-lg text-zinc-500 border border-zinc-850">
                              <User size={15} />
                            </div>
                            <div>
                              <p className="text-[9px] text-zinc-500 uppercase font-bold">Vendedor</p>
                              <p className="font-bold text-white text-xs">{selectedVehicleForDetails.advertiserName || 'Loja Localiza'}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2.5 text-zinc-300">
                            <div className="p-2 bg-zinc-900 rounded-lg text-zinc-500 border border-zinc-850">
                              <MapPin size={15} />
                            </div>
                            <div>
                              <p className="text-[9px] text-zinc-500 uppercase font-bold">Localidade</p>
                              <p className="font-bold text-white text-xs">{selectedVehicleForDetails.city || 'Maringá - PR'}</p>
                            </div>
                          </div>
                        </div>

                        {selectedVehicleForDetails.phone && (
                          <div className="flex items-center gap-2.5 text-zinc-300 mt-2">
                            <div className="p-2 bg-zinc-900 rounded-lg text-zinc-500 border border-zinc-850">
                              <Phone size={15} />
                            </div>
                            <div>
                              <p className="text-[9px] text-zinc-500 uppercase font-bold">Telefone / WhatsApp</p>
                              <p className="font-bold text-blue-400 text-xs">{selectedVehicleForDetails.phone}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Pricing & CTA CTA Whatsapp integration */}
                    <div className="border-t border-zinc-900 pt-5 mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <p className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-wider">Valor do Investimento</p>
                        <h3 className="text-2xl font-black text-blue-500">{formatCurrency(selectedVehicleForDetails.price)}</h3>
                      </div>

                      {selectedVehicleForDetails.phone ? (
                        <a 
                          id="whatsapp-cta-link"
                          href={`https://wa.me/${selectedVehicleForDetails.phone.replace(/\D/g, '').startsWith('55') ? selectedVehicleForDetails.phone.replace(/\D/g, '') : '55' + selectedVehicleForDetails.phone.replace(/\D/g, '')}?text=Olá,%20tenho%20interesse%20no%20anúncio%20do%20${encodeURIComponent(selectedVehicleForDetails.brand)}%20${encodeURIComponent(selectedVehicleForDetails.model)}%20no%20Localiza%20Veículos.%20Link%20do%20anúncio:%20${encodeURIComponent(`${window.location.origin}${window.location.pathname}?vehicle=${selectedVehicleForDetails.id}`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 border border-green-500/20 bg-green-600 hover:bg-green-700 font-extrabold text-white px-6 py-3.5 rounded-2xl text-xs uppercase tracking-widest text-center shadow-lg shadow-green-950/20 hover:scale-105 active:scale-95 duration-200 transition-all"
                        >
                          <MessageSquare size={16} />
                          Falar no WhatsApp
                        </a>
                      ) : (
                        <div className="text-zinc-500 text-xs font-semibold">Contato indisponível</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
