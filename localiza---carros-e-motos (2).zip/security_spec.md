# Security Specification for Xororo

## Data Invariants
- Vehicles must have a brand, model, year, price, and type (car/motorcycle).
- Clients must have a name, email, and phone.
- Only users listed in the `admins` collection can create/update/delete vehicles and manage clients.
- The `admins` collection itself is protected; only existing admins can add new ones.

## The "Dirty Dozen" Payloads (Examples)
1. **Unauthorized Create Vehicle**: Non-signed-in user tries to add a car.
2. **Unauthorized Update Vehicle**: Authenticated user (not admin) tries to change a price.
3. **Identity Spoofing**: Admin tries to set `ownerId` of a vehicle to another user ID.
4. **Invalid Vehicle Price**: Setting price to -100.
5. **PII Leak**: Non-admin user tries to read the `clients` collection.
6. **State Poisoning**: Injecting 1MB of garbage into `brand` field.
7. **Unauthorized Admin Elevation**: Regular user tries to add themselves to the `admins` collection.
8. **Invalid Vehicle Type**: Setting type to 'airplane'.
9. **Missing Required Fields**: Creating a vehicle without a `price`.
10. **Admin Identity Spoofing**: User tries to create an entry in `admins` with their own UID without permission.
11. **Client Data Integrity**: Creating a client with an invalid email format (basic size check).
12. **Vehicle Year Limit**: Setting year to 3000.

## Firestore Rules Drafting... (to follow in firestore.rules)
